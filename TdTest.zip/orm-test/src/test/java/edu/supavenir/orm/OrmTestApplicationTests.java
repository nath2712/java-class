package edu.supavenir.orm;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class OrmTestApplicationTests {

	@Test
	void contextLoads() {
	}

}
