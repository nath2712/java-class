package edu.supavenir.contest.repositories;

import org.springframework.data.jpa.repository.JpaRepository;


import edu.supavenir.models.Organisation;

public interface OrgaRepository extends JpaRepository<Organisation, Integer > {


	
	
}
