package edu.supavenir.orm;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class OrmTestApplication {

	public static void main(String[] args) {
		SpringApplication.run(OrmTestApplication.class, args);
	}

}
